package Aplikasi_Human_Resource.services;

public interface MyService<T> {
    void saveMenus(T t);

//    int updateMenu(Menu menu);
//
//    int deleteMenu(Menu menu);
//
//    public List<Menu> findAll();
//
//    public List<Menu> search(String keyword);
}
